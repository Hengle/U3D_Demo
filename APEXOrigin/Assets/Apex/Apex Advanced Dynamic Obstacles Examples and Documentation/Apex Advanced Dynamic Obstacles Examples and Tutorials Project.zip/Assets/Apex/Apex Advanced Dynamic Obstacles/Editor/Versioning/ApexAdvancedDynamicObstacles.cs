﻿/* Copyright © 2014 Apex Software. All rights reserved. */
using Apex.Editor.Versioning;

[assembly: ApexProductAttribute("Advanced Dynamic Obstacles", "1.0.1", ProductType.Extension)]
