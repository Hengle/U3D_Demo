﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace FairyGUI
{
	/// <summary>
	/// 
	/// </summary>
	public class Stats
	{
		/// <summary>
		/// 
		/// </summary>
		public static int ObjectCount;

		/// <summary>
		/// 
		/// </summary>
		public static int GraphicsCount;

		/// <summary>
		/// 
		/// </summary>
		public static int LatestObjectCreation;

		/// <summary>
		/// 
		/// </summary>
		public static int LatestGraphicsCreation;
	}
}
